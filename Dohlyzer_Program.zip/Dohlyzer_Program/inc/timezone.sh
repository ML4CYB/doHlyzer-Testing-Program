#!/bin/bash

export TZ=US/Michigan